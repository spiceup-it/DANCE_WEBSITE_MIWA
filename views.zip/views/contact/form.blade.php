@extends('layout.app')

@section('content')
<div class="contact">
	<div class="bg_detail">
		<img src="img/bg/contact.jpg">
		<h2>Contact</h2>
	</div>
	<div class="detail">
		<div class="jumbotron">
			<h2>Contact</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eum nihil magnam odit temporibus veritatis architecto facere, ab molestiae doloribus. Ratione eius, libero optio! Deserunt excepturi doloremque iure, sunt quae ducimus.</p>
			<div class="contact-form">
			{!! Form::open(['url' => '/contact/submit']) !!}

				<!--Name-->
				<div class="form-group">
			         {{ Form::label('name', 'Your Name') }}
			         {{ Form::text('name', '',['class'=>'form-control','placeholder'=>'Enter your Name'])}}
		         </div>
		         <!--Email-->
				<div class="form-group">
	          		{{ Form::label('email', 'Your Email') }}
	            	{{ Form::text('email', '',['class'=>'form-control','placeholder'=>'Enter your Email'])}}
	            </div>
	            <!--Message-->
	            <div class="form-group">
			         {{ Form::label('message', 'Your Message') }}
			         {{ Form::textarea('message', '',['class'=>'form-control','placeholder'=>'Enter your Message','rows' => 5, 'cols' => 50])}}
	            </div>

	        {{form:: submit('Submit', ['class'=>'contact-btn mx-auto d-block'])}}
			{!! Form::close() !!}
			</div>
			<div class="row sns">
				<div class="col-lg-4 col-sm-4">
					<a href="https://www.instagram.com/zono30/"><img src="img/sns/instagram.png"></a>
				</div>
				<div class="col-lg-4 col-sm-4">
					<a href="https://www.facebook.com/miwa.tezono">
					<img src="img/sns/facebook.png">
					</a>
				</div>
				<div class="col-lg-4 col-sm-4">
					<a href="#">
					<img src="img/sns/twitter.png">
					</a>
				</div>
			</div>
			<div class="contact-deco1">
				<img src="img/contact/contact-bg1.jpg">
			</div>
			<div class="contact-deco2">
				<img src="img/contact/contact-bg2.jpg">
			</div>
		</div>
	</div>
</div>
@endsection