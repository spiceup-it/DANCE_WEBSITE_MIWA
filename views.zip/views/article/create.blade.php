@extends('layout.app')

@section('content')
<div class="blog-edit">
	<div class="detail">
		<div class="jumbotron">
			<h2>Add New Blog</h2>
			
			<form method="post" action="/blog/create">
				{{ csrf_field() }}
				<!--Article title-->
				<div class="form-group">
					<label for="titleInput">Title</label>
					<input type="text" class="form-control" id="titleInput" name="title">
				</div>

				<!--Article contents-->
				<div class="form-group">
					<label for="titleInput">Contents</label>
					<textarea class="form-control" id="bodyInput" row="10" name="body"></textarea> 
				</div>

				<button type="submit" class="btn btn-primary">Add New Article</button>
			</form>	
			<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
    		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
		</div>
	</div>
</div>
@endsection