@extends('layout.app')

@section('content')
<div class="blog">
	<div class="bg_detail">
		<img src="img/bg/blog.jpg">
		<h2>Blog</h2>
	</div>
	<div class="detail">
		<div class="jumbotron">
			<h2>Dance Academy Blog</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate eos beatae, ratione vero! Inventore accusamus voluptate, eaque numquam quaerat, eius adipisci qui incidunt, neque eos praesentium magni reiciendis delectus debitis.</p>
			<p><a href="/blog/create" class="btn btn-primary">Add New Article</a></p>
			<div class="blog-article">
			@foreach($articles as $article)
				<div class="card mb-2">
					<div class="card-body">
						<h4 class="card-title">{{ $article->title }}</h4>
						<h6 class="card-subtitle mb-2 text-muted">{{ $article->updated_at }}</h6>
						<p class="card-text">{{ $article->body }}</p>
						<a href="/blog/edit/{{ $article->id }}" class="card-link">Edit</a>
						<a href="/blog/delete/{{ $article->id }}" class="card-link">Delete</a>
					</div>
				</div>
			@endforeach
			</div>

			<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
    		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
		</div>
	</div>
</div>
@endsection