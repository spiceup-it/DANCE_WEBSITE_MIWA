	<script>
		function changeProfile() {
			$('#image').click();
		}
		$('#image').change(function(){
			var imgPath = $(this)[0].value;
			var ext = imgPath.substring(imgPath.lastIndexOf('.')+1).toLowerCase();
			if (ext == "gif" || ext == "png" || ext == "jpg" || ext == "jpeg")
				readURL(this);
			else
				alert("Please select image file (jpg, jpeg, png).")
		});
		function readURL(input) {
			if(input.files && input.files[0]){
				var reader = new FileReader();
				reader.readAsDataURL(input.files[0]);
				reader.onload = function (e){
					$('#preview').attr('src', e.target.result);
                    $('#remove').val(0);
				}
			}
		}
		function removeImage(){
			$('#preview').attr('src', '{{url('images/noimage.jpg')}}');
            $('#remove').val(1);
		}
	</script>