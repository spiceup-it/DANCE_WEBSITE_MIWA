@extends('layout.app')

@section('content')
<div class="gallery">
	<div class="bg_detail">
		<img src="img/bg/gallery.jpg">
		<h2>Gallery</h2>
	</div>
	<div class="detail">
		<div class="jumbotron">
			<h2>Gallery</h2>
        	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus eius quidem, voluptas inventore ab! Distinctio nam officia, nobis et dolores quod, quos architecto perferendis nihil in, debitis quibusdam eius dignissimos.</p>
			
			<div class="row">
				@foreach($images as $image)
				<div class="col-md-4 col-lg-3 frame">
					<div class="card">
						<img class="card-img-top"  src="{{url($image->image? 'uploads/'.$image->image:'images/noimage.jpg')}}"alt="{{$image->description}}">
						<div class="card-body">
                            <h6 class="card-title text-center">{{ucwords($image->description)}}</h6>
                        </div>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">
                                <form id="frm_{{$image->id}}"
                                      action="{{url('gallery/delete/'.$image->id)}}"
                                      method="post" style="padding-bottom: 0px;margin-bottom: 0px">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <a href="javascript:if(confirm('Are you sure want to delete?')) $('#frm_{{$image->id}}').submit()"
                                               class="btn btn-danger btn-sm btn-block">Delete</a>
                                        </div>
                                        <div class="col-sm-6">
                                            <a href="{{url('gallery/update/'.$image->id)}}"
                                               class="btn btn-primary btn-sm btn-block">Edit</a>
                                        </div>
                                        <input type="hidden" name="_method" value="delete"/>
                                        {{csrf_field()}}
                                    </div>
                                </form>
                            </li>
                        </ul>
					</div>
				</div>
				@endforeach
			</div>
        	<div class="float-right">
            <a href="{{url('gallery/create')}}" class="btn btn-primary">New</a>
        	</div>
		</div>
	</div>
	<nav>
            <ul class="pagination justify-content-end">
                {{$images->links('vendor.pagination.bootstrap-4')}}
            </ul>
        </nav>
</div>
@endsection