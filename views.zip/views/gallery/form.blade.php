@extends('layout.app')

@section('content')
<div class="gallery-edit">
	<div class="detail">
		<div class="jumbotron">
			<div class="col-md-8 offset-md-2">
				<h2>{{isset($image)?'Edit':'New'}} Image</h2>
				<hr>
				@if(isset($image))
					{!! Form::model($image,['method'=>'put','files'=>true]) !!}
				@else
					{!! Form::open(['files'=>true]) !!}
				@endif
				<div class="form-group row">
					{!! Form::label("image","Image",["class"=>"col-form-label col-md-3"]) !!}
					<div class="col-md-5">
						<img id="preview" src="{{asset((isset($image) && $image->image!='')?'uploads/'.$image->image:'images/noimage.jpg')}}" height="200px" width="200px">
						{!! Form::file("image",["class"=>"form-control","style"=>"display:none"]) !!}
						<br>
						<a href="javascript:changeProfile();">Change</a> |
                    	<a style="color: red" href="javascript:removeImage()">Remove</a>
                    	<input type="hidden" style="display: none" value="0" name="remove" id="remove">
					</div>
				</div>
				 <div class="form-group row required">
                	{!! Form::label("description","Description",["class"=>"col-form-label col-md-3 col-lg-2"]) !!}
                	<div class="col-md-8">
                    	{!! Form::text("description",null,["class"=>"form-control".($errors->has('description')?" is-invalid":""),"autofocus",'placeholder'=>'Description']) !!}
                    	{!! $errors->first('description','<span class="invalid-feedback">:message</span>') !!}
                	</div>
            	</div>
            	<div class="form-group row">
                	<div class="col-md-3 col-lg-2"></div>
               		<div class="col-md-4">
                    	<a href="{{url('laravel-crud-image-gallery')}}" class="btn btn-danger">Back</a>
                    	{!! Form::button("Save",["type" => "submit","class"=>"btn btn-primary"])!!}
               		 </div>
            	</div>
            	{!! Form::close() !!}
			</div>
		</div>
	</div>
</div>
@endsection