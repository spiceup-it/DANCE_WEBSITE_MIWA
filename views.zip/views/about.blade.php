@extends('layout.app')

@section('content')
<div class="about">
	<div class="bg_detail">
		<img src="img/bg/about.jpg">
		<h2>About</h2>
	</div>
	<div class="detail">
		<div class="jumbotron">
			<h2>Dance Academy</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi, obcaecati. Voluptas cumque alias omnis ratione, a possimus ullam nobis, quo iure laboriosam natus expedita cupiditate autem odit asperiores incidunt. Aliquam.
			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ea qui praesentium minus fugit, libero, id pariatur possimus quibusdam esse accusantium ipsum, ratione sit incidunt aliquam beatae maiores nihil dolorum, aspernatur!
			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facere repellendus, ullam necessitatibus quae, sint animi! Optio ratione incidunt voluptas excepturi quasi eum suscipit repellat nulla possimus. Illo reiciendis quibusdam, fuga.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facere repellendus, ullam necessitatibus quae, sint animi! Optio ratione incidunt voluptas excepturi quasi eum suscipit repellat nulla possimus. Illo reiciendis quibusdam, fuga.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facere repellendus, ullam necessitatibus quae, sint animi! Optio ratione incidunt voluptas excepturi quasi eum suscipit repellat nulla possimus. Illo reiciendis quibusdam, fuga.</p>
			<div class="row">
					<div class="aboutpic col-lg-4 col-sm-12">
						<img src="img/blog/blog1.jpg">
					</div>
					<div class="aboutpic col-lg-4 col-sm-12">
						<img src="img/blog/blog2.jpg">
					</div>
					<div class="aboutpic col-lg-4 col-sm-12">
						<img src="img/blog/blog3.jpg">
					</div>
			</div>
		</div>
	</div>
</div>
@endsection