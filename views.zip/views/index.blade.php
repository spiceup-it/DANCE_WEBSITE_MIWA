@extends('layout.app')

@section('content')
<div class="main_contents">
	<div class="bg">
		<img src="img/dancepagebg.jpg">
		<div class="coment">
			<h1>Dance in Life</h1>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis architecto a amet, distinctio earum praesentium laborum natus, animi eveniet possimus voluptas adipisci repellendus, id pariatur fugit qui. Sunt, quod assumenda.</p>
		</div>
	</div>
</div>
	@include('top.class_top')
	@include('top.about_top')
	@include('top.blog_top')
	@include('top.map_top')
	@include('top.gallery_top')
@endsection