<div id="about-top" class="top">
	<div class="container">
		<h2>About</h2>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis eligendi accusantium libero sunt similique aliquid distinctio ipsa est porro iure enim, ut officia vitae perspiciatis. Illo accusantium, a fugiat Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae, magni, ipsum? Ad, sed debitis incidunt iure vero quos ab cupiditate delectus deleniti velit sit necessitatibus aut beatae est fugit in.</p>
		<a href="about" class="btn1">Read More</a>
	</div>
</div>