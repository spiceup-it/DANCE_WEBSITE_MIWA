<div id="class-top" class="top">
	<div class="container">
		<div class="row">
			<div class="col-lg-2 col-sm-6 class-icon">
				<a href="/class"><img src="img/class-top/hiphop.png">
				<p>HipHop</p></a>
			</div>
			<div class="col-lg-2 col-sm-6 class-icon">
				<a href="/class"><img src="img/class-top/jazz.png">
				<p>Jazz</p></a>
			</div>
			<div class="col-lg-2 col-sm-6 class-icon">
				<a href="/class"><img src="img/class-top/bollywood.png">
				<p>Bollywood</p></a>
			</div>
			<div class="col-lg-2 col-sm-6 class-icon">
				<a href="/class"><img src="img/class-top/comtemporary.png">
				<p>Comtemporary</p></a>
			</div>
			<div class="col-lg-2 col-sm-6 class-icon">
				<a href="/class"><img src="img/class-top/zumba.png">
				<p>Zumba</p></a>
			</div>
			<div class="col-lg-2 col-sm-6 class-icon">
				<a href="/class"><img src="img/class-top/yoga.png">
				<p>Yoga</p></a>
			</div>
		</div>
	</div>
</div>