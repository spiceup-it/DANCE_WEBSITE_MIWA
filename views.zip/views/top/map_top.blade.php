<div id="map-top" class="top">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-sm-12 address">
				<div class="map-address">
					
						<h3><img src="/img/dance-logo-w.png"></h3>
					
					<div class="address">
						<h5>1234 Koramangala #101<br>Bangalore Kanataka 98000</h5>
					</div>
					<div class="tel">
						<div class="icon">
							<img src="img/icon/phone.png">
						</div>
						<h5>+919022222222</h5>
					</div>
					<br>
					<div class="email">
						<div class="icon">
							<img src="img/icon/email.png">
						</div>
						<h5>danceacademy@gmail.com</h5>
					</div>
					<div class="snsicon">
						<img src="img/icon/instagram.png">
						<img src="img/icon/facebook.png">
						<img src="img/icon/twitter.png">
					</div>
				</div>
			</div>
			<div id="map-img" class=" col-lg-6 col-sm-12">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.58518623738!2d77.61649337847813!3d12.934361290925008!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae14fd1dd89889%3A0xcd2bdb1dc3f5b444!2sSpiceup+Academy+English+and+Japanese+Language+School!5e0!3m2!1sen!2sin!4v1531475615343" width="400" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
				<!--	<img src="img/map-google.gif">-->
			</div>
		</div>
	</div>
</div>