<div id="gallery-top" class="top">
	<div class="container">
		<h2>Gallery</h2>
		<div class="row">
			<div class="col-lg-2 col-sm-4">
				<img src="img/gallery/gallery1.jpg">
			</div>
			<div class="col-lg-2 col-sm-4">
				<img src="img/gallery/gallery2.jpg">
			</div>
			<div class="col-lg-2 col-sm-4">
				<img src="img/gallery/gallery3.jpg">
			</div>
			<div class="col-lg-2 col-sm-4">
				<img src="img/gallery/gallery4.jpg">
			</div>
			<div class="col-lg-2 col-sm-4">
				<img src="img/gallery/gallery5.jpg">
			</div>
			<div class="col-lg-2 col-sm-4">
				<img src="img/gallery/gallery6.jpg">
			</div>
		</div>
		<div class="gallery-btn">
			<a href="gallery" class="btn1">Gallery More</a>
		</div>
	</div>
</div>