<div id="blog-top" class="top">
	<div class="container">
		<h2>Studio Blog</h2>
		<div id="newarticle">
			<div class="row">
				<div class="new-blog col-lg-4 col-sm-12">
					<img src="img/blog/blog1.jpg">
					<div class="detail">
					<h4>Title1</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
					</div>
				</div>
				<div class="new-blog col-lg-4 col-sm-12">
					<img src="img/blog/blog2.jpg">
					<div class="detail">
					<h4>Title2</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
					</div>
				</div>
				<div class="new-blog col-lg-4 col-sm-12">
					<img src="img/blog/blog3.jpg">
					<div class="detail">
					<h4>Title3</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
					</div>
				</div>
			</div>
		</div>
		<a href="#" class="btn2">
			Read More
		</a>
	</div>
</div>