@extends('layout.app')

@section('content')
<div class="dance-class">
	<div class="bg_detail">
		<img src="img/bg/class.jpg">
		<h2>Class</h2>
	</div>
	<div class="detail">
		<div class="jumbotron">
			<h2>Class</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus cum ducimus, minus quisquam tempore sint quam corporis. Quas nemo pariatur exercitationem, adipisci, veritatis illum maiores voluptatibus ipsum, saepe ducimus aspernatur.</p>
			<div class="class-detail">
				<!--HipHop-->
				<div class="d-class" id="hiphop">
					<div class="row">
						<h4>HipHop</h4>
					</div>
					<div class="row row-line">
						<div class="col-lg-6 col-sm-12">
							<img src="img/class/hiphop.jpg">
						</div>
						<div class="col-lg-6 col-sm-12">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt quae, reprehenderit maxime esse expedita quaerat labore voluptas impedit, velit, doloribus blanditiis ad deleniti sequi quibusdam amet quas exercitationem voluptatibus excepturi.</p>
							<h5>Time</h5>
							<p>Monday, Tuesday</p>
						</div>
					</div>
				</div><!--end of HipHop-->

				<!--JazzDance-->
				<div class="jazz d-class">
					<div class="row">
						<h4>JazzDance</h4>
						<h5 class="deco-line">
						</h5>
					</div>
					<div class="row row-line">
						<div class="col-lg-6 col-sm-12">
							<img src="img/class/jazzdance.jpg">
						</div>
						<div class="col-lg-6 col-sm-12">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt quae, reprehenderit maxime esse expedita quaerat labore voluptas impedit, velit, doloribus blanditiis ad deleniti sequi quibusdam amet quas exercitationem voluptatibus excepturi.</p>
							<h5>Time</h5>
							<p>Monday, Tuesday</p>
						</div>
					</div>
				</div><!--end of JazzDance-->

				<!--Bollywood-->
				<div class="bollywood d-class">
					<div class="row">
						<h4>Bollywood</h4>
					</div>
					<div class="row row-line">
						<div class="col-lg-6 col-sm-12">
							<img src="img/class/bollywood.jpg">
						</div>
						<div class="col-lg-6 col-sm-12">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt quae, reprehenderit maxime esse expedita quaerat labore voluptas impedit, velit, doloribus blanditiis ad deleniti sequi quibusdam amet quas exercitationem voluptatibus excepturi.</p>
							<h5>Time</h5>
							<p>Monday, Tuesday</p>
						</div>
					</div>
				</div><!--end of Bollywood-->

				<!--Comtemporary-->
				<div class="comtemporary d-class">
					<div class="row">
						<h4>Comtemporary</h4>
					</div>
					<div class="row row-line">
						<div class="col-lg-6 col-sm-12">
							<img src="img/class/comtemporary.jpg">
						</div>
						<div class="col-lg-6 col-sm-12">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt quae, reprehenderit maxime esse expedita quaerat labore voluptas impedit, velit, doloribus blanditiis ad deleniti sequi quibusdam amet quas exercitationem voluptatibus excepturi.</p>
							<h5>Time</h5>
							<p>Monday, Tuesday</p>
						</div>
					</div>
				</div><!--end of Comtemporary-->

				<!--Zumba-->
				<div class="zumba d-class">
					<div class="row">
						<h4>Zumba</h4>
					</div>
					<div class="row row-line">
						<div class="col-lg-6 col-sm-12">
							<img src="img/class/zumba.jpg">
						</div>
						<div class="col-lg-6 col-sm-12">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt quae, reprehenderit maxime esse expedita quaerat labore voluptas impedit, velit, doloribus blanditiis ad deleniti sequi quibusdam amet quas exercitationem voluptatibus excepturi.</p>
							<h5>Time</h5>
							<p>Monday, Tuesday</p>
						</div>
					</div>
				</div><!--end of Zumba-->

				<!--Yoga-->
				<div class="zumba d-class">
					<div class="row">
						<h4>Yoga</h4>
					</div>
					<div class="row row-line">
						<div class="col-lg-6 col-sm-12">
							<img src="img/class/yoga.jpg">
						</div>
						<div class="col-lg-6 col-sm-12">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt quae, reprehenderit maxime esse expedita quaerat labore voluptas impedit, velit, doloribus blanditiis ad deleniti sequi quibusdam amet quas exercitationem voluptatibus excepturi.</p>
							<h5>Time</h5>
							<p>Monday, Tuesday</p>
						</div>
					</div>
				</div><!--end of Yoga-->

			</div>
		</div>
	</div>
</div>
@endsection