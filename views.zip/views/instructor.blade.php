@extends('layout.app')

@section('content')
<div class="instructor">
	<div class="bg_detail">
		<img src="img/bg/instructor.jpg">
		<h2>Instructor</h2>
	</div>
	<div class="detail">
		<div class="jumbotron">
			<h2>Instructor</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facere repellendus, ullam necessitatibus quae, sint animi! Optio ratione incidunt voluptas excepturi quasi eum suscipit repellat nulla possimus. Illo reiciendis quibusdam, fuga.</p>
			<div class="profile">
				<div class="row">
					<div class="col-lg-6 col-sm-12">
						<img src="img/instructor/teacher1.jpg">
					</div>
					<div class="col-lg-6 col-sm-12 p-woman">
							<h3 class="woman">Anna</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Placeat rerum non iure at distinctio ea possimus, illo eveniet accusantium libero fugiat, quibusdam officia officiis temporibus deserunt voluptatum nostrum enim, ex.</p>

							<div class="dance-class">
								<h6>Class</h6>
								<p>HipHop JazzDance</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6 col-sm-12">
						<img src="img/instructor/teacher2.jpg">
					</div>
					<div class="col-lg-6 col-sm-12 p-man">
						<h3 class="man">Reccard</h3>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Placeat rerum non iure at distinctio ea possimus, illo eveniet accusantium libero fugiat, quibusdam officia officiis temporibus deserunt voluptatum nostrum enim, ex.</p>
						<div class="dance-class">
						<h6>Class</h6>
							<p>HipHop JazzDance</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6 col-sm-12">
						<img src="img/instructor/teacher1.jpg">
					</div>
					<div class="col-lg-6 col-sm-12 p-woman">
							<h3 class="woman">Anna</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Placeat rerum non iure at distinctio ea possimus, illo eveniet accusantium libero fugiat, quibusdam officia officiis temporibus deserunt voluptatum nostrum enim, ex.</p>

							<div class="dance-class">
								<h6>Class</h6>
								<p>HipHop JazzDance</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6 col-sm-12">
						<img src="img/instructor/teacher2.jpg">
					</div>
					<div class="col-lg-6 col-sm-12 p-man">
						<h3 class="man">Reccard</h3>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Placeat rerum non iure at distinctio ea possimus, illo eveniet accusantium libero fugiat, quibusdam officia officiis temporibus deserunt voluptatum nostrum enim, ex.</p>
						<div class="dance-class">
						<h6>Class</h6>
							<p>HipHop JazzDance</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6 col-sm-12">
						<img src="img/instructor/teacher1.jpg">
					</div>
					<div class="col-lg-6 col-sm-12 p-woman">
							<h3 class="woman">Anna</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Placeat rerum non iure at distinctio ea possimus, illo eveniet accusantium libero fugiat, quibusdam officia officiis temporibus deserunt voluptatum nostrum enim, ex.</p>

							<div class="dance-class">
								<h6>Class</h6>
								<p>HipHop JazzDance</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6 col-sm-12">
						<img src="img/instructor/teacher2.jpg">
					</div>
					<div class="col-lg-6 col-sm-12 p-man">
						<h3 class="man">Reccard</h3>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Placeat rerum non iure at distinctio ea possimus, illo eveniet accusantium libero fugiat, quibusdam officia officiis temporibus deserunt voluptatum nostrum enim, ex.</p>
						<div class="dance-class">
						<h6>Class</h6>
							<p>HipHop JazzDance</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection