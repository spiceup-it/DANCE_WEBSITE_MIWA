@extends('layout.app')

@section('content')
<div class="fqa">
	<div class="bg_detail">
		<img src="img/bg/fqa.jpg">
		<h2>FQA</h2>
	</div>
	<div class="detail">
		<div class="jumbotron">
			<h2>FQA</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed odit illo inventore nisi, architecto assumenda eos provident, eveniet facere qui, excepturi magni earum adipisci odio expedita repellendus, officia et! Esse?</p>
			<div class="fqa-detail">
				<div class="question">
					<h3><span>Q.</span>Question1</h3>
				</div>
				<div class="answer">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi reprehenderit explicabo illum cum deleniti officia sequi excepturi minima, aliquam dolor. Perspiciatis doloribus ipsam, nulla assumenda veritatis nemo tenetur, voluptatibus accusantium.
				</div>
			</div>
			<div class="fqa-detail">
				<div class="question">
					<h3><span>Q.</span>Question1</h3>
				</div>
				<div class="answer">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi reprehenderit explicabo illum cum deleniti officia sequi excepturi minima, aliquam dolor. Perspiciatis doloribus ipsam, nulla assumenda veritatis nemo tenetur, voluptatibus accusantium.
				</div>
			</div>
			<div class="fqa-detail">
				<div class="question">
					<h3><span>Q.</span>Question1</h3>
				</div>
				<div class="answer">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi reprehenderit explicabo illum cum deleniti officia sequi excepturi minima, aliquam dolor. Perspiciatis doloribus ipsam, nulla assumenda veritatis nemo tenetur, voluptatibus accusantium.
				</div>
			</div>
			<div class="fqa-detail">
				<div class="question">
					<h3><span>Q.</span>Question1</h3>
				</div>
				<div class="answer">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi reprehenderit explicabo illum cum deleniti officia sequi excepturi minima, aliquam dolor. Perspiciatis doloribus ipsam, nulla assumenda veritatis nemo tenetur, voluptatibus accusantium.
				</div>
			</div>
			<div class="fqa-detail">
				<div class="question">
					<h3><span>Q.</span>Question1</h3>
				</div>
				<div class="answer">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi reprehenderit explicabo illum cum deleniti officia sequi excepturi minima, aliquam dolor. Perspiciatis doloribus ipsam, nulla assumenda veritatis nemo tenetur, voluptatibus accusantium.
				</div>
			</div>
			<div class="fqa-detail">
				<div class="question">
					<h3><span>Q.</span>Question1</h3>
				</div>
				<div class="answer">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi reprehenderit explicabo illum cum deleniti officia sequi excepturi minima, aliquam dolor. Perspiciatis doloribus ipsam, nulla assumenda veritatis nemo tenetur, voluptatibus accusantium.
				</div>
			</div>
			<div class="fqa-detail">
				<div class="question">
					<h3><span>Q.</span>Question1</h3>
				</div>
				<div class="answer">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi reprehenderit explicabo illum cum deleniti officia sequi excepturi minima, aliquam dolor. Perspiciatis doloribus ipsam, nulla assumenda veritatis nemo tenetur, voluptatibus accusantium.
				</div>
			</div>
			<div class="fqa-detail">
				<div class="question">
					<h3><span>Q.</span>Question1</h3>
				</div>
				<div class="answer">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi reprehenderit explicabo illum cum deleniti officia sequi excepturi minima, aliquam dolor. Perspiciatis doloribus ipsam, nulla assumenda veritatis nemo tenetur, voluptatibus accusantium.
				</div>
			</div>
		</div>
	</div>
</div>
@endsection