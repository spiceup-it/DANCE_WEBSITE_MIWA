<footer>
	<div class="footer-nav">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-sm-12">
					<div class="footer-logo">
						<img src="/img/dance-logo-w.png">
					</div>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Libero fuga voluptate quas inventore fugit, suscipit nostrum est exercitationem voluptatibus quaerat modi recusandae temporibus quasi fugiat consequuntur commodi, sit veniam obcaecati.</p>
				</div>
				<div class="col-lg-6 col-sm-12 footer-nav2">
					<ul>
						<li><a href="/">HOME</a></li>
						<li><a href="/about">ABOUT</a></li>
						<li><a href="/class">CLASS</a></li>
						<li><a href="/instructor">INSTRUCTOR</a></li>
					</ul>
					<br>	
					<ul>
						<li><a href="/gallery">GALLERY</a></li>
						<li><a href="/contact">CONTACT</a></li>
						<li><a href="/blog">BLOG</a></li>
						<li><a href="/fqa">FQA</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="footer-bottom">
		<p class="container">
			Copyright 2018 &copy; Miwa
		</p>
	</div>
</footer>